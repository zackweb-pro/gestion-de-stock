<?php

if(isset($_GET['idAce'])){
        include("../cnx.php");
        $id = $_GET['idAce'];
        $req = "INSERT INTO sous_admin  (IDSou,name,LOGIN ,Password,Adress)
                SELECT * FROM `acepter_sousadmin` WHERE `idAce` = $id";
        $res=mysqli_query($cnx,$req);
        header("Location:Delete.php?idAce=$id");
}else{
        header("Location:../index.php");
}

?>
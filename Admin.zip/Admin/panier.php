<?php
session_start();
if(isset($_SESSION['name'])){
        require('fpdf/fpdf.php');
        class PDF extends FPDF{
    // Page header
    function Header(){
        $this->SetFont('Arial','B',16);
        $this->ln(30);

    }
    function Footer(){
        $this->ln(-60);
    }

    }
    $pdf = new PDF();
    $pdf->AddPage();
    $pdf->Cell(60);
    $pdf->Cell(100,0,' BONE DE LIVRAISON ',0,0,'c');
    $pdf->SetFont('Arial','B',12);
    $pdf->SetFillColor(200,200,200);
    include("../cnx.php");
    if(isset($_GET['idclient'])){
    $id=$_GET['idclient'];
    $req="SELECT * from client,produit,vante where produit.Ref = vante.Ref and client.idClient = vante.idClient and client.idClient='$id' ";
    $res=mysqli_query($cnx,$req);
    $d=mysqli_fetch_assoc($res);
    $pdf->ln(10);
    $pdf->Cell(6);
    $pdf->Cell(30,12,' NUMERO',1,0,'C',true);
    $pdf->Cell(30,12,' DATE',1,0,'C',true);
    $pdf->Cell(48,12,' MODE DE PAIEMENT ',1,0,'C',true);
    $pdf->Cell(36,12,' CLIENT',1,0,'C',true);
    $pdf->SetFont('Arial','',10);
    $pdf->Cell(36,12,' '.$d['name'].' ',1,1,'C',);

    $pdf->Cell(6);
    $pdf->SetFont('Arial','',10);
    $pdf->Cell(30,12,' '.$d['idVante'].' ',1,0,'C');
    $pdf->Cell(30,12,' '.$d['date'].' ',1,0,'C');
    $pdf->Cell(48,12,' '.$d['Modepaiment'].' ',1,0,'C');
    $pdf->SetFont('Arial','B',12);
    $pdf->Cell(36,12,' ADRESSE',1,0,'C');
    $pdf->SetFont('Arial','',10);
    $pdf->Cell(36,12,' '.$d['adresseClient'].' ',1,1,'C',);

    $pdf->Cell(6);
    $pdf->Cell(30,12,' ',0,0,'C');
    $pdf->Cell(30,12,' ',0,0,'C');
    $pdf->Cell(48,12,'  ',0,0,'C');
    $pdf->SetFont('Arial','B',12);
    $pdf->Cell(36,12,' TELE',1,0,'C');
    $pdf->SetFont('Arial','',10);
    $pdf->Cell(36,12,' '.$d['tel'].' ',1,1,'C',);

    $pdf->Cell(6);
    $pdf->Cell(30,12,' ',0,0,'C');
    $pdf->Cell(30,12,' ',0,0,'C');
    $pdf->Cell(48,12,'  ',0,0,'C');
    $pdf->SetFont('Arial','B',12);
    $pdf->Cell(36,12,' VILLE',1,0,'C');
    $pdf->SetFont('Arial','',10);
    $pdf->Cell(36,12,' '.$d['Ville'].' ',1,1,'C',);



    $pdf->SetFont('Arial','B',12);
    $pdf->ln(10);
    $pdf->Cell(6);
    $pdf->Cell(36,12,' REFERENCE',1,0,'C',true);
    $pdf->Cell(36,12,' DESIGNATION',1,0,'C',true);
    $pdf->Cell(30,12,' QTE',1,0,'C',true);
    $pdf->Cell(42,12,' PRIX UNITE',1,0,'C',true);
    $pdf->Cell(36,12,' MONTANT TTC ',1,1,'C',true);

    $req1="SELECT * from client,produit,vante where produit.Ref = vante.Ref and client.idClient = vante.idClient and client.idClient='$id' ";
    $res1=mysqli_query($cnx,$req1);
    $s=0;
    $pdf->Cell(6);  
    while($data=mysqli_fetch_assoc($res1)){ 

            $montant=$data['Qte']*$data['PrixU'];
            $pdf->Cell(36,12,' '.$data['Ref'].' ',1,0,'C');
            $pdf->Cell(36,12,' '.$data['designation'].' ',1,0,'C');
            $pdf->Cell(30,12,' '.$data['Qte'].' ',1,0,'C');
            $pdf->Cell(42,12,' '.$data['PrixU'].' ',1,0,'C');
            $pdf->Cell(36,12,' '.$montant.' ',1,1,'C');
            $s=$s+$montant;
            $pdf->Cell(6);

    }
    $pdf->Cell(36,12,' ',0,0,'C');
    $pdf->Cell(36,12,' ',0,0,'C');
    $pdf->Cell(30,12,' ',0,0,'C');
    $pdf->Cell(42,12,' NET A PAYER TTC ',1,0,'C');
    $pdf->Cell(36,12,' '.$s.' ',1,1,'C');

    }

    $pdf->Cell(6);
    $pdf->ln(10);
    $pdf->Cell(36,12,' ',0,0,'C');
    $pdf->Cell(36,12,' ',0,0,'C');
    $pdf->Cell(30,12,' ',0,0,'C');
    $pdf->Cell(42,12,' ',0,0,'C');
    $pdf->Cell(36,12,' SIGNATURE ',0,1,'C');

    $pdf->Output();
}else{
    header("Location:../index.php");
}
?>
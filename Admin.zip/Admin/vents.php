<?php
    session_start();
    if(isset($_SESSION['name'])){
?>
<!DOCTYPE html>
 <html lang="en">
 <head>
    <meta charset="UTF-8">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="icon" href="../img/log.svg">
    <title>EL FATOUAKY</title>
    <link rel="stylesheet" href="style.css">
 </head>
 <body>
    <div class="side-bar">
    <div class="logo" >
            <img src="image/log.svg" alt="">
        </div>
        <div class="menu">
            <?php
            if(isset($_SESSION["sous_admin"])){
            ?>
                <a href="index 1.php"><span class="material-icons">dashboard</span> &nbsp Graphe</a>
                <a href="produits.php"><span class="material-icons">shopping_cart</span> &nbsp Produits</a>
                <a href="Addproduits.php"><span class="material-icons">add_shopping_cart</span> &nbsp Add Produits</a>
                <a href="clients.php"><span class="material-icons">groups</span> &nbsp Clients</a>
                <a href="vents.php"><span class="material-icons">add_business</span> &nbsp Ventes</a> 
            <?php
            }else{
            ?>
                <a href="index.php"><span class="material-icons">dashboard</span> &nbsp Graphe</a>
                <a href="Addadmin.php"><span class="material-icons">group_add</span> &nbsp Add Admins</a>
                <a href="produits.php"><span class="material-icons">shopping_cart</span> &nbsp Produits</a>
                <a href="Addproduits.php"><span class="material-icons">add_shopping_cart</span> &nbsp Add Produits</a>
                <a href="clients.php"><span class="material-icons">groups</span> &nbsp Clients</a>
                <a href="vents.php"><span class="material-icons">add_business</span> &nbsp Ventes</a>
            <?php
            }
            ?>       
        </div>
    </div>
    <div class="container">
        <div class="header">
        <div class="RADIATEUR-Text">EST</div>
            <div class="nav">
                <div class="user">
                    <a href="Disconnect.php" class="btn">Disconnect</a>
                </div>
            </div>
        </div>
        <div class="content">
            <div class="vents ALL">
                        <div class="search">
                            <center><div class="left" >
                            <form method="post" action="" class="rech">
                            <input type="text" name="recherche" id="inp" placeholder="Recherche un designation" class="tab2"></form>
                            </div> </center>
                            <table class="tab2">
                                <thead>
                                    <tr>
                                    <th>Referance</th>
                                    <th>Designation</th>
                                    <th>Quantite</th>
                                    <th>Prix unite</th>
                                    </tr>
                                    <?php 
                                        include("../cnx.php");
                                        if(isset($_POST["recherche"])){
                                            $rech=$_POST["recherche"];
                                            $req="SELECT * from produit where designation like'%$rech%'";
                                            $res=mysqli_query($cnx,$req);
                                            while($d=mysqli_fetch_assoc($res)){
                                                ?>
                                                <tr>          
                                            <form method="post" action="" class="rech">
                                                <td><?=$d['Ref']?></td>
                                                <input type="hidden" name="Ref" id="inp" value="<?=$d['Ref']?>">
                                                <td><?=$d['designation']?></td>
                                                <input type="hidden" name="designation" id="inp" value="<?=$d['designation']?>">
                                                <td><input type="text" name="qte" id="inp" ></td>
                                                <td><?=$d['PrixU']?></td>
                                                <input type="hidden" name="PrixU" id="inp" value="<?=$d['PrixU']?>">
                                                    <td><span class='action_btn'><input type="submit" name="btn" value="AJOUTER" onclick="myFunction();"><br></span></td>
                                            </form>
                                                </tr>
                                                <?php  
                                                }
                                                }
                                                ?>
                                            <?php  
                                        if(!isset($_POST["recherche"])){
                                            $req="SELECT * from produit ";
                                            $res=mysqli_query($cnx,$req);
                                            while($d=mysqli_fetch_assoc($res)){
                                                ?>
                                            <tr>
                                            <form method="post" action="" class="rech">
                                                <td><?=$d['Ref']?></td>
                                                <input type="hidden" name="Ref" id="inp" value="<?=$d['Ref']?>">
                                                <td><?=$d['designation']?></td>
                                                <input type="hidden" name="designation" id="inp" value="<?=$d['designation']?>">
                                                <td><input type="text" name="qte" id="inp" ></td>
                                                <td><?=$d['PrixU']?></td>
                                                <input type="hidden" name="PrixU" id="inp" value="<?=$d['PrixU']?>">
                                                <td><span class='action_btn'><input type="submit" name="btn" value="AJOUTER" onclick="myFunction();"><br></span></td>
                                                </tr>
                                            </form>
                                            <?php  
                                            }}
                                            ?>
                                        </form>

                                </thead>
                            </table>   
            <?php
              if(isset($_POST['btn'])){
                $ref=$_POST['Ref'];
                $desination=$_POST['designation'];
                $qte=$_POST['qte'];
                $prix=$_POST['PrixU'];
                include("../cnx.php");
                $req="INSERT INTO newprod value ('$ref','$desination',$qte,'$prix')";
                $res=mysqli_query($cnx,$req);
              }            
            ?>
            </div>
            <div id="extra-select">
                        <h3 class="tab2" style="font-size:2vw;display: flex;justify-content: center;">les ventes</h3>
                        <table class="tab2">
                            <thead>
                                <tr>
                                <th>Referance</th>
                                <th>Designation</th>
                                <th>Quantite</th>
                                <th>Prix unite</th>

                                </tr>
                                    <?php 
                                        include("../cnx.php");
                                            $req="SELECT * from newprod";
                                            $res=mysqli_query($cnx,$req);
                                            while($d=mysqli_fetch_assoc($res)){
                                                $ref=$d['Ref'];
                                                $newqte=$d['Qte'];
                                                $req1="UPDATE produit set Quantite= Quantite-$newqte where Ref='$ref'";
                                                $res1=mysqli_query($cnx,$req1);
                                                ?>
                                                <tr>
                                                    <td><?=$d['Ref']?></td>
                                                    <td><?=$d['designation']?></td>
                                                    <td><?=$d['Qte']?></td>
                                                    <td><?=$d['PrixU']?></td>
                                                </tr>
                                                <?php  
                                                }
                                                ?>
                            </thead>
                        </table> 
                        <span class='action_btn'><a href='Delete.php?Refera=0' style="background-color: red;color: #fff; margin:20px; margin-left:900px;font-size:1.5vw;">Delete All</a></span>


                        <hr>
                    <div class="form">
                        <form action="tretment.php" method="post" target="framename">
                            <fieldset>
                            <legend>Saisir les informations de client</legend>
                                <input type="text" name="cni" placeholder="cni" ><br>
                                <input type="text" name="Name" placeholder="Name" ><br>
                                <input type="text" name="Adress" placeholder="Adress"><br>
                                <input type="text" name="Ville" placeholder="Ville"><br>
                                <input type="text" name="Tele" placeholder="Telephone"><br>
                                <input type="text" name="mode" placeholder="Mode paiment"><br>
                                <input type="date" name="Date" ><br>
                            </fieldset>
                            <input type="submit" name="btn" value="AJOUTER AU PANIER"><br>
                        </form>
                    </div>
                </div>
            </div> 
        </div> 
</body>
<?php
    }else{
        header("Location:../index.php");
    }
?>

<?php
    session_start();
    if(isset($_SESSION['name'])){
?>
<!DOCTYPE html>
 <html lang="en">
 <head>
    <meta charset="UTF-8">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="icon" href="../img/log.svg">
    <title>EL FATOUAKY</title>
    <link rel="stylesheet" href="style.css">
 </head>
 <body>
    <div class="side-bar">
    <div class="logo" >
            <img src="image/log.svg" alt="">
        </div>
        <div class="menu">
            <?php               
                if(isset($_SESSION["sous_admin"])){
            ?>
                <a href="index 1.php"><span class="material-icons">dashboard</span> &nbsp Graphe</a>
                <a href="produits.php"><span class="material-icons">shopping_cart</span> &nbsp Produits</a>
                <a href="Addproduits.php"><span class="material-icons">add_shopping_cart</span> &nbsp Add Produits</a>
                <a href="clients.php"><span class="material-icons">groups</span> &nbsp Clients</a>
                <a href="vents.php"><span class="material-icons">add_business</span> &nbsp Ventes</a> 
            <?php
                }else{
            ?>
                <a href="index.php"><span class="material-icons">dashboard</span> &nbsp Graphe</a>
                <a href="Addadmin.php"><span class="material-icons">group_add</span> &nbsp Add Admins</a>
                <a href="produits.php"><span class="material-icons">shopping_cart</span> &nbsp Produits</a>
                <a href="Addproduits.php"><span class="material-icons">add_shopping_cart</span> &nbsp Add Produits</a>
                <a href="clients.php"><span class="material-icons">groups</span> &nbsp Clients</a>
                <a href="vents.php"><span class="material-icons">add_business</span> &nbsp Ventes</a>
            <?php
                }
            ?>       
        </div>
    </div>
    <div class="container">
        <div class="header">
        <div class="RADIATEUR-Text">EST</div>
            <div class="nav">
                <div class="user">
                    <a href="Disconnect.php" class="btn">Disconnect</a>
                </div>
            </div>
        </div>
        <div class="content">
                <div class="ADDproduit ALL">
                <div class="form">
                        <form action="ajouter.php" method="post">
                            <fieldset>
                            <legend>Add Produit</legend>
                                <input type="text" name="Ref" placeholder="Ref"><br>
                                <input type="text" name="designation" placeholder="designation"><br>
                                <input type="text" name="Quantite" placeholder="Quantite"><br>
                                <input type="text" name="PrixU" placeholder="PrixU"><br>
                            </fieldset>
                            <input type="submit" name="btn" value="ADD"><br>
                        </form>
                    </div>
                </div>
        </div>
    </div>
 </body>
<?php
    }else{
        header("Location:../index.php");
    }
?>
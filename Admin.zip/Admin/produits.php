<?php
    session_start();
    if(isset($_SESSION['name'])){
?>
<!DOCTYPE html>
 <html lang="en">
 <head>
    <meta charset="UTF-8">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="icon" href="../img/log.svg">
    <title>EL FATOUAKY</title>
    <link rel="stylesheet" href="style.css">
 </head>
 <body>
    <div class="side-bar">
    <div class="logo" >
            <img src="image/log.svg" alt="">
        </div>
        <div class="menu">
            <?php
                if(isset($_SESSION["sous_admin"])){
            ?>
                <a href="index 1.php"><span class="material-icons">dashboard</span> &nbsp Graphe</a>
                <a href="produits.php"><span class="material-icons">shopping_cart</span> &nbsp Produits</a>
                <a href="Addproduits.php"><span class="material-icons">add_shopping_cart</span> &nbsp Add Produits</a>
                <a href="clients.php"><span class="material-icons">groups</span> &nbsp Clients</a>
                <a href="vents.php"><span class="material-icons">add_business</span> &nbsp Ventes</a> 
            <?php
                }else{
            ?>
                <a href="index.php"><span class="material-icons">dashboard</span> &nbsp Graphe</a>
                <a href="Addadmin.php"><span class="material-icons">group_add</span> &nbsp Add Admins</a>
                <a href="produits.php"><span class="material-icons">shopping_cart</span> &nbsp Produits</a>
                <a href="Addproduits.php"><span class="material-icons">add_shopping_cart</span> &nbsp Add Produits</a>
                <a href="clients.php"><span class="material-icons">groups</span> &nbsp Clients</a>
                <a href="vents.php"><span class="material-icons">add_business</span> &nbsp Ventes</a>
            <?php
                }
            ?>      
        </div>
    </div>
    <div class="container">
        <div class="header">
            <div class="RADIATEUR-Text">EST</div>
            <div class="nav">
                <div class="user">
                    <a href="Disconnect.php" class="btn">Disconnect</a>
                </div>
            </div>
        </div>
        <div class="content">
        <div class="produit ALL">
            <div class="search">
            <center><div class="left">
                <form method="post" action="" class="rech">
                <input type="text" name="recherche" id="inp" placeholder="Recherche un designation"></form>
                </div> </center>
                <table>
                    <thead>
                        <tr>
                        <th>Referance</th>
                        <th>Designation</th>
                        <th>Quantite</th>
                        <th>Prix unite</th>
                        <th></th>
                        </tr>
                        <?php 
                            include("../cnx.php");
                            if(isset($_POST["recherche"])){
                                $rech=$_POST["recherche"];
                                $req="SELECT * from produit where designation like'%$rech%'";
                                $res=mysqli_query($cnx,$req);
                                while($d=mysqli_fetch_assoc($res)){
                                    ?>
                                    <tr>
                                        <td><?=$d['Ref']?></td>
                                        <td><?=$d['designation']?></td>
                                        <td><?=$d['Quantite']?></td>
                                        <td><?=$d['PrixU']?></td>
                                        <td><span class='action_btn'><a href='update.php?Ref=<?=$d['Ref']?>'>UPDATE</a><a href='Delete.php?Ref=<?=$d['Ref']?>'>Delete</a></span></td>
                                    </tr>
                                    <?php  
                                     }
                                    }
                                    ?>
                                   <?php  
                               if(!isset($_POST["recherche"])){
                                $req="SELECT * from produit ";
                                $res=mysqli_query($cnx,$req);
                                while($d=mysqli_fetch_assoc($res)){
                                    ?>
                                <tr>
                                    <td><?=$d['Ref']?></td>
                                    <td><?=$d['designation']?></td>
                                    <td><?=$d['Quantite']?></td>
                                    <td><?=$d['PrixU']?></td>
                                    <td><span class='action_btn'><a href='update.php?Ref=<?=$d['Ref']?>'>UPDATE</a><a href='Delete.php?Ref=<?=$d['Ref']?>'>Delete</a></span></td>
                                </tr>
                                <?php  
                                }}
                                ?>

                    </thead>
                 </table>     
                 <span class='action_btn'><a href='Delete.php?id=0' style="background-color: red;color: #fff; margin:20px; margin-left:900px;font-size:1.5vw;">Delete All</a></span>
            </div>
        </div>
    </div>
 </body>
<?php
    }else{
        header("Location:../index.php");
    }
?>
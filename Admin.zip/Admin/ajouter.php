<?php
if(isset($_POST['btn'])){
    include("../cnx.php");
    $Ref=$_POST['Ref'];
    $designation=$_POST['designation'];
    $Quantite=$_POST['Quantite'];
    $PrixU=$_POST['PrixU'];
    $req="INSERT INTO produit (Ref,designation,Quantite,PrixU) VALUES ('$Ref','$designation',$Quantite,'$PrixU')";
    $res=mysqli_query($cnx,$req);
    if(isset($res)){header("Location:produits.php");}
}else{
    header("Location:../index.php");
}
?>
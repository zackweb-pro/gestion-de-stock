<?php
if(isset($_GET["idAce"])){
    include("../cnx.php");
    $id = $_GET["idAce"];
    $req = "DELETE FROM acepter_sousadmin WHERE idAce=$id";
    $res=mysqli_query($cnx,$req);
    header("Location:Addadmin.php");
}
if(isset($_GET["Ref"])){
    include("../cnx.php");
    $id = $_GET["Ref"];
    $req = "DELETE FROM produit WHERE Ref='$id'";
    $res=mysqli_query($cnx,$req);
    header("Location:produits.php");
}
if(isset($_GET["id"])){
    include("../cnx.php");
    $id = $_GET["id"];
    if($id==0){
    $req = "DELETE FROM produit";
    $res=mysqli_query($cnx,$req);
    header("Location:produits.php");
    }
}
if(isset($_GET["Refera"])){
    include("../cnx.php");
    $id = $_GET["Refera"];
    if($id==0){
    $req="SELECT * from newprod";
    $res=mysqli_query($cnx,$req);
    while($d=mysqli_fetch_assoc($res)){
        $ref=$d['Ref'];
        $newqte=$d['Qte'];
        $req3="SELECT * from produit WHERE Ref ='$ref'";
        $res3=mysqli_query($cnx,$req3);
        $do=mysqli_fetch_assoc($res3);
        $q=$do['Quantite']+($newqte*2);
        $req1="UPDATE produit SET Quantite=$q WHERE Ref ='$ref'";
        $res1=mysqli_query($cnx,$req1);
        if($res1){
       $req2= "DELETE FROM newprod";
       $res2=mysqli_query($cnx,$req2);
       header("Location:vents.php");
        }
    }
    }
}

if(isset($_GET["vide"])){
    include("../cnx.php");
    $id = $_GET["vide"];
    if($id==0){
    $req = "DELETE FROM vante";
    $req1 = "DELETE FROM client";
    $res=mysqli_query($cnx,$req);
    $res1=mysqli_query($cnx,$req1);
    header("Location:index.php");
    }
}
?>
<?php
    if(isset($_GET["Ref"])){
        include("../cnx.php");
        $id = $_GET["Ref"];
        $req = "SELECT * FROM produit WHERE Ref='$id'";
        $res=mysqli_query($cnx,$req);
        $d=mysqli_fetch_assoc($res);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <script src="https://kit.fontawesome.com/7e525043ba.js" crossorigin="anonymous"></script>
    <link rel="icon" href="../img/log.svg">
<title>EL FATOUAKY</title>
    <link rel="stylesheet" href="update.css">
 </head>
<body >
    <div class="container">
		<div class="contact-box"style="">
			<div class="right">
				<h2>UPDATE Produit</h2>
                <div  class="it">
                    <form action="" method="post">
                    <div style="font-size:1.5vw;color:#fff;">Referance</div> <br><input type="text" name="Ref" placeholder="Ref" value="<?=$d['Ref']?>"><br>
                    <div style="font-size:1.5vw;color:#fff;">Designation</div> <br><input type="text" name="designation" placeholder="designation" value="<?=$d['designation']?>"><br>
                    <div style="font-size:1.5vw;color:#fff;">Quantite</div> <br><input type="text" name="Quantite" placeholder="Quantite" value="<?=$d['Quantite']?>"><br>
                    <div style="font-size:1.5vw;color:#fff;">Prix unite</div> <br><input type="text" name="PrixU" placeholder="PrixU" value="<?=$d['PrixU']?>"><br>
                        <input type="submit" name="btn" value="ADD"><br>
                    </form>
                 </div>
			</div>

		</div>
	</div>
</body>
</html>
<?php
if(isset($_POST['btn'])){
    include("../cnx.php");
    $Ref=$_POST['Ref'];
    $designation=$_POST['designation'];
    $Quantite=$_POST['Quantite'];
    $PrixU=$_POST['PrixU'];
    $req1="UPDATE produit set Ref='$Ref',designation='$designation',Quantite=$Quantite,PrixU='$PrixU' where Ref='$id' ";
    $res1=mysqli_query($cnx,$req1);
    if(isset($res1)){
        header("Location:produits.php");
        }
    }
}else{
    header("Location:../index.php");
}
?>
<?php
    if(isset($_POST["btn"])){
        $Name=$_POST["Name"];
        $Adress=$_POST["Adress"];
        $Ville=$_POST["Ville"];
        $Tele=$_POST["Tele"];
        $Date=$_POST["Date"];
        $cni=$_POST["cni"];
        $mode=$_POST["mode"];
        include("../cnx.php");
        $req="INSERT INTO client value ('$cni','$Name','$Adress','$Ville','$Tele')";
        $res=mysqli_query($cnx,$req);
        if(isset($res)){
            $req="SELECT Ref,Qte from newprod";
            $res=mysqli_query($cnx,$req);
            while($d=mysqli_fetch_assoc($res)){
                $qte=$d['Qte'];
                $ref=$d['Ref'];
                $req1="INSERT INTO vante (Modepaiment,date,Ref,idClient,Qte) value ('$mode','$Date','$ref','$cni',$qte)";
                $res1=mysqli_query($cnx,$req1);
                if(isset($res1)){
                    $req2="DELETE from newprod ";
                    $res2=mysqli_query($cnx,$req2);
                    if(isset($res2)){
                    header("Location:panier.php?idclient=".$cni);
                    }
                }
            }
        }
    }else{
        header("Location:../index.php");
    }
?>
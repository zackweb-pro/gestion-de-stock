<?php
    session_start();
    if(isset($_SESSION['name'])){
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="icon" href="../img/log.svg">
    <title>EL FATOUAKY</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="side-bar">
    <div class="logo" >
            <img src="image/log.svg" alt="">
        </div>
        <div class="menu">
            <a href="index.php"><span class="material-icons">dashboard</span> &nbsp Graphe</a>
            <a href="Addadmin.php"><span class="material-icons">group_add</span> &nbsp Add Admins</a>
            <a href="produits.php"><span class="material-icons">shopping_cart</span> &nbsp Produits</a>
            <a href="Addproduits.php"><span class="material-icons">add_shopping_cart</span> &nbsp Add Produits</a>
            <a href="clients.php"><span class="material-icons">groups</span> &nbsp Clients</a>
            <a href="vents.php"><span class="material-icons">add_business</span> &nbsp Ventes</a>      
        </div>
    </div>
    <div class="container">
        <div class="header">
        <div class="RADIATEUR-Text">EST</div>
            <div class="nav">
                <div class="user">
                    <a href="../AUTEN.php" class="btn">Disconnect</a>
                </div>
            </div>
        </div>
        <div class="content">
        <div class="ADD ALL">

                <table>
                    <thead>
                    <tr>
                        <th>N°</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Password</th>
                        <th>ADRESS</th>
                        <th>ADD/DELETE</th>
                    </tr>
                    
                    <?php 
                    include("../cnx.php");
                    $req="SELECT * from  acepter_sousadmin ";
                    $res=mysqli_query($cnx,$req);
                    while($d=mysqli_fetch_assoc($res)){
                        ?>
                        <tr>
                        <td><?=$d['idAce']?></td>
                        <td><?=$d['name']?></td>
                        <td><?=$d['LOGIN']?></td>
                        <td><?=$d['Password']?></td>
                        <td><?=$d['Adress']?></td>
                        <td><span class='action_btn'><a href='Accepte.php?idAce=<?=$d['idAce']?>'>Accepte</a><a href='Delete.php?idAce=<?=$d['idAce']?>'>Delete</a></span></td>
                    </tr>
                    <?php  
                    }
                    ?>
                    
                    </thead>
                    <tbody>
                    </tbody>
                </table>
                </div>
        </div>
    </div>
</body>
<?php
    }else{
        header("Location:../index.php");
    }
?>
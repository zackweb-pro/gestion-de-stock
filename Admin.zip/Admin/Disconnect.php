<?php
    session_start();
    if(isset($_SESSION["sous_admin"])){
        session_destroy();
        header("Location:../AUTEN.php");
    }
    header("Location:../index.php");
?>
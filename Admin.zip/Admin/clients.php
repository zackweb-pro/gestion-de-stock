<?php
    session_start();
    if(isset($_SESSION['name'])){
?>
<!DOCTYPE html>
 <html lang="en">
 <head>
    <meta charset="UTF-8">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="icon" href="../img/log.svg">
    <title>EL FATOUAKY</title>
    <link rel="stylesheet" href="style.css">
 </head>
 <body>
    <div class="side-bar">
    <div class="logo" >
            <img src="image/log.svg" alt="">
        </div>
        <div class="menu">
            <?php           
            if(isset($_SESSION["sous_admin"])){
            ?>
                <a href="index 1.php"><span class="material-icons">dashboard</span> &nbsp Graphe</a>
                <a href="produits.php"><span class="material-icons">shopping_cart</span> &nbsp Produits</a>
                <a href="Addproduits.php"><span class="material-icons">add_shopping_cart</span> &nbsp Add Produits</a>
                <a href="clients.php"><span class="material-icons">groups</span> &nbsp Clients</a>
                <a href="vents.php"><span class="material-icons">add_business</span> &nbsp Ventes</a> 
            <?php
            }else{
            ?>
                <a href="index.php"><span class="material-icons">dashboard</span> &nbsp Graphe</a>
                <a href="Addadmin.php"><span class="material-icons">group_add</span> &nbsp Add Admins</a>
                <a href="produits.php"><span class="material-icons">shopping_cart</span> &nbsp Produits</a>
                <a href="Addproduits.php"><span class="material-icons">add_shopping_cart</span> &nbsp Add Produits</a>
                <a href="clients.php"><span class="material-icons">groups</span> &nbsp Clients</a>
                <a href="vents.php"><span class="material-icons">add_business</span> &nbsp Ventes</a>
            <?php
            }
            ?>     
        </div>
    </div>
    <div class="container">
        <div class="header">
        <div class="RADIATEUR-Text">EST</div>

            <div class="nav">
                <div class="user">
                    <a href="Disconnect.php" class="btn">Disconnect</a>
                </div>
            </div>
        </div>
        <div class="content">
        <div class="produit ALL">
            <div class="search">
            <center><div class="left">
                <form method="post" action="" class="rech">
                <input type="text" name="recherche" id="inp" placeholder="Recherche un Nom"></form>
                </div> </center>
                <table>
                    <thead>
                        <tr>
                        <th>Nom</th>
                        <th>Adress</th>
                        <th>ville</th>
                        <th>tel</th>
                        <th>Date</th>
                        <th>designation</th>
                        <th>Referance</th>
                        <th>QUANTITE</th>
                        </tr>
                        <?php 
                            include("../cnx.php");
                            if(isset($_POST["recherche"])){
                                $rech=$_POST["recherche"];
                                $req="SELECT * from client,produit,vante where produit.Ref = vante.Ref 
                                    and client.idClient = vante.idClient and name like'%$rech%'";
                                $res=mysqli_query($cnx,$req);
                                while($d=mysqli_fetch_assoc($res)){
                                    ?>
                                    <tr>          
                                    <td><?=$d["name"]?></td>
                                    <td><?=$d["adresseClient"]?></td>
                                    <td><?=$d["Ville"]?></td>
                                    <td><?=$d["tel"]?></td>
                                    <td><?=$d["date"]?></td>
                                    <td><?=$d["designation"]?></td>
                                    <td><?=$d["Ref"]?></td>
                                    <td><?=$d["Qte"]?></td>
                                    </tr>
                                    <?php  
                                    }
                                    }
                                    ?>
                                <?php  
                            if(!isset($_POST["recherche"])){
                                $req="SELECT * from client,produit,vante where produit.Ref = vante.Ref 
                                and client.idClient = vante.idClient ";
                                $res=mysqli_query($cnx,$req);
                                while($d=mysqli_fetch_assoc($res)){
                                    ?>
                                        <tr>          
                                        <td><?=$d["name"]?></td>
                                        <td><?=$d["adresseClient"]?></td>
                                        <td><?=$d["Ville"]?></td>
                                        <td><?=$d["tel"]?></td>
                                        <td><?=$d["date"]?></td>
                                        <td><?=$d["designation"]?></td>
                                        <td><?=$d["Ref"]?></td>
                                        <td><?=$d["Qte"]?></td>
                                        </tr>
                                <?php  
                                }}
                                ?>
                                <tr>
                    </thead>
                 </table>
                 <span class='action_btn'><a href='Delete.php?vide=0' style="background-color: red;color: #fff; margin:20px; margin-left:900px;font-size:1.2vw;">Vide cache</a></span> 
                </div>
        </div>
    </div>
 </body>
 <?php
    }else{
        header("Location:../index.php");
    }
?>
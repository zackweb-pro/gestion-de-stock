<?php
session_start();
if(isset($_SESSION['name'])){
    $_SESSION["sous_admin"] = true;
?>
<!DOCTYPE html>
 <html lang="en">
 <head>
    <meta charset="UTF-8">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="icon" href="../img/log.svg">
    <title>EL FATOUAKY</title>
    <link rel="stylesheet" href="style.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
 </head>
 <body>
    <div class="side-bar">
        <div class="logo" >
            <img src="image/log.svg" alt="">
        </div>
        <div class="menu">
            <a href="index 1.php"><span class="material-icons">dashboard</span> &nbsp Graphe</a>
            <a href="produits.php"><span class="material-icons">shopping_cart</span> &nbsp Produits</a>
            <a href="Addproduits.php"><span class="material-icons">add_shopping_cart</span> &nbsp Add Produits</a>
            <a href="clients.php"><span class="material-icons">groups</span> &nbsp Clients</a>
            <a href="vents.php"><span class="material-icons">add_business</span> &nbsp Ventes</a>      
        </div>
    </div>
      <div class="container">
        <div class="header">
        <div class="RADIATEUR-Text">EST</div>
            <div class="nav">
                <div class="user">
                    <a href="Disconnect.php" class="btn">Disconnect</a>
                </div>
            </div>
        </div>
        <div class="content">
            <div class="cards">
                <div class="card card1">
                    <div class="box">
                        <h1><?php 
                        require("../cnx.php");
                        $res = $cnx->query("SELECT COUNT(*) FROM produit");
                        $count = $res->fetch_row();
                        print_r($count[0]);?></h1>
                        <h3>Produits</h3>
                    </div>
                    <div class="icon-design">
                        <img src="image/produit.png">
                    </div>
                </div>
                <div class="card card3">
                    <div class="box">
                        <h1>
                        <?php $res = $cnx->query("SELECT COUNT(*) FROM client");
                        $count = $res->fetch_row();
                        print_r($count[0]);?>
                        </h1>
                        <h3>Clients</h3>
                    </div>
                    <div class="icon-design">
                        <img src="image/client.png">
                    </div>
                </div>
            </div>
            <div style="display: flex; flex-direction: column; align-items: center;">
                <h2 class="T-Graphic">Graphic of Sales</h2>
                <canvas id="myChart"></canvas>
                
                <?php
                    $cnx = new mysqli("localhost", "root", "", "radiateurf");

                    $query = "SELECT DISTINCT designation as 'U_designation' FROM vante v, produit p WHERE v.Ref = p.Ref";
                    $res = $cnx->query($query);
                
                    while ($data = $res->fetch_assoc()) {
                        $id = $data["U_designation"];
                        $resul = $cnx->query("SELECT SUM(Qte) as 'T_Qte' FROM vante v, produit p WHERE v.Ref = p.Ref AND p.designation = '$id'");
                        $d = $resul->fetch_assoc();
                        $Totale_Qtl[] = $d["T_Qte"];
                        $U_designation[] = $id;
                    }
                ?>

                <script>
                    const ctx = document.getElementById('myChart');
                    new Chart(ctx, {
                        type: 'bar',
                        data: {
                        labels: <?php echo json_encode($U_designation)?>,
                        datasets: [{
                            label: '',
                            data: <?php echo json_encode($Totale_Qtl)?>,
                            backgroundColor: [
                            'rgba(153, 102, 255, 0.2)',
                            'rgba(255, 159, 64, 0.2)',
                            'rgba(75, 192, 192, 0.2)',
                            'rgba(255, 206, 86, 0.2)',
                            'rgba(54, 162, 235, 0.2)',
                            'rgba(255, 99, 132, 0.2)'
                            ],
                            borderColor: [
                            'rgba(153, 102, 255, 1)',
                            'rgba(255, 159, 64, 1)',
                            'rgba(75, 192, 192, 1)',
                            'rgba(255, 99, 132, 1)',
                            'rgba(54, 162, 235, 1)',
                            'rgba(255, 206, 86, 1)'
                            
                            ],
                            borderWidth: 1
                        }]
                        },
                        options: {
                        scales: {
                            y: {
                            beginAtZero: true
                            }
                        }
                        }
                    });
                </script>
            </div>
        </div>
      </div>
 </body>
 <?php
    }else{
        header("Location:../index.php");
    }
?>